/*
 * Auteur : Jacob Amaury                 |\      _,,,---,,_
 * Date   : 10102025 00:15:51     ZZZzz  /,`.-'`'    -.  ;-;;,_
 *                                      |,4-  ) )-,_. ,\ (  `'-' 
 */                                    '---''(_/--'  `-'\_)

To run this code you should go in the main folder then open a terminal and type python3 main.py
